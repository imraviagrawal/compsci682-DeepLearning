# Assume the virtualenv is called .env

cp frameworkpython dl/bin
dl/bin/frameworkpython -m Jupyter notebook
